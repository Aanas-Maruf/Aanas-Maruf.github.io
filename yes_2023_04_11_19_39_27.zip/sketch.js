function setup() {
 createCanvas(400, 400,WEBGL);
 
}
function draw() {
  background("grey")
   normalMaterial()
 push();
 rotateZ(frameCount * 0.19);
 rotateX(frameCount * 0.18);
 rotateY(frameCount * 0.19);
 torus(100,20)
 pop();
}